# TerrariaCartographer

## Overview
A tool that reads Terraria world files, and polls tShock APIs, to produce a 'live' world map complete with player locations.

## Usage
```
python3 -m TerrariaCartographer -f /root/.local/Terraria/worlds/world.wld -H 127.0.0.1 -t tShockExampleRestApiKey -o outputImage.png
```
python3 -m TerrariaCartographer -f $PWD/Outrageous_Dell.wld -H 10.2.1.151 -t E3E91F77CDC8F12A92C9CBE048727182971B38D44CEAD53FA593B375D0E2F9A8 -o Outrageous_Dell.png
python3 -m TerrariaCartographer -f /root/.local/share/Terraria/worlds/Outrageous_Dell.wld -H 10.2.1.151 -t E3E91F77CDC8F12A92C9CBE048727182971B38D44CEAD53FA593B375D0E2F9A8 -o Outrageous_Dell.png
## Development

1. Install Build Dependancies
    Debian: `apt install build-essential libssl-dev zlib1g-dev libbz2-dev libreadline-dev libsqlite3-dev curl libncursesw5-dev xz-utils tk-dev libxml2-dev libxmlsec1-dev libffi-dev liblzma-dev`

2. Install pyenv
`curl https://pyenv.run | bash`

3. Install Python3
`pyenv install 3.11`

4. Install Poetry
`curl -sSL https://install.python-poetry.org | python3 -`
